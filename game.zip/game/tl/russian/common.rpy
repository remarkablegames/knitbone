﻿# TODO: Translation updated at 2026-02-20 03:15

translate russian strings:

    # renpy/common/000statements.rpy:28
    old "Click to play the video."
    new "Нажмите, чтобы воспроизвести видео."

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "Синтезатор речи отключён."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "Озвучивание буфера обмена включено."

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "Синтезатор речи включён."

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "полоса"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "выбранный"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "окно просмотра"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "горизонтальная прокрутка"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "вертикальная прокрутка"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "включить"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "выключить"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "увеличить"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "уменьшить"

    # renpy/common/00accessibility.rpy:134
    old "Self-Voicing"
    new "Синтезатор речи"

    # renpy/common/00accessibility.rpy:137
    old "Self-voicing support is limited when using a touch screen."
    new "Поддержка синтезатора речи ограничена при использовании сенсорного экрана."

    # renpy/common/00accessibility.rpy:139
    old "Off"
    new "Выкл."

    # renpy/common/00accessibility.rpy:143
    old "Text-to-speech"
    new "Преобразование текста в речь"

    # renpy/common/00accessibility.rpy:147
    old "Clipboard"
    new "Буфер обмена"

    # renpy/common/00accessibility.rpy:151
    old "Debug"
    new "Отладка"

    # renpy/common/00accessibility.rpy:163
    old "Reset"
    new "Сброс"

    # renpy/common/00accessibility.rpy:167
    old "Self-Voicing Volume Drop"
    new "Падение громкости при автоозвучке"

    # renpy/common/00accessibility.rpy:180
    old "Mono Audio"
    new "Монофонический звук"

    # renpy/common/00accessibility.rpy:182
    old "Enable"
    new "Включить"

    # renpy/common/00accessibility.rpy:186
    old "Disable"
    new "Отключить"

    # renpy/common/00accessibility.rpy:198
    old "Font Override"
    new "Переопределение шрифта"

    # renpy/common/00accessibility.rpy:200
    old "Default"
    new "По умолчанию"

    # renpy/common/00accessibility.rpy:204
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:208
    old "Opendyslexic"
    new "Opendyslexic"

    # renpy/common/00accessibility.rpy:212
    old "High Contrast Text"
    new "Текст с высокой контрастностью"

    # renpy/common/00accessibility.rpy:224
    old "Text Size Scaling"
    new "Масштабирование размера текста"

    # renpy/common/00accessibility.rpy:235
    old "Line Spacing Scaling"
    new "Масштабирование межстрочного интервала"

    # renpy/common/00accessibility.rpy:246
    old "Kerning"
    new "Кернинг"

    # renpy/common/00accessibility.rpy:267
    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Меню доступности. Используйте стрелки вверх и вниз для навигации, клавишу Enter для активации кнопок и полос."

    # renpy/common/00accessibility.rpy:288
    old "Self-Voicing and Audio"
    new "Синтезатор речи и звук"

    # renpy/common/00accessibility.rpy:292
    old "Text"
    new "Текст"

    # renpy/common/00accessibility.rpy:296
    old "Return"
    new "Назад"

    # renpy/common/00accessibility.rpy:306
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Опции в этом меню предназначены для улучшения доступности. Они могут работать не во всех играх, а некоторые комбинации опций могут сделать игру непроходимой. Это не проблема игры или движка. Для достижения наилучших результатов при изменении шрифтов старайтесь сохранять размер текста таким же, как был изначально."

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}Понедельник"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}Вторник"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}Среда"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}Четверг"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}Пятница"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}Суббота"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}Воскресенье"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}Пн"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}Вт"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}Ср"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}Чт"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}Пт"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}Сб"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}Вс"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}Январь"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}Февраль"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}Март"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}Апрель"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}Май"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}Июнь"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}Июль"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}Август"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}Сентябрь"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}Октябрь"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}Ноябрь"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}Декабрь"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}Янв"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}Фев"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}Мар"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}Апр"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}Май"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}Июн"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}Июл"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}Авг"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}Сен"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}Окт"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}Ноя"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}Дек"

    # renpy/common/00action_file.rpy:258
    old "%b %d, %H:%M"
    new "%b %d, %H:%M"

    # renpy/common/00action_file.rpy:395
    old "Save slot %s: [text]"
    new "Ячейка сохранения %s: [text]"

    # renpy/common/00action_file.rpy:481
    old "Load slot %s: [text]"
    new "Загрузка сохранения %s: [text]"

    # renpy/common/00action_file.rpy:534
    old "Delete slot [text]"
    new "Удалить сохранение [text]"

    # renpy/common/00action_file.rpy:613
    old "File page auto"
    new "Автоматическая страница файлов"

    # renpy/common/00action_file.rpy:615
    old "File page quick"
    new "Быстрая страница файла"

    # renpy/common/00action_file.rpy:617
    old "File page [text]"
    new "Страница файлов [text]"

    # renpy/common/00action_file.rpy:816
    old "Next file page."
    new "Следующая страница файлов."

    # renpy/common/00action_file.rpy:888
    old "Previous file page."
    new "Предыдущая страница файлов."

    # renpy/common/00action_file.rpy:949
    old "Quick save complete."
    new "Быстрое сохранение завершено."

    # renpy/common/00action_file.rpy:964
    old "Quick save."
    new "Быстрое сохранение."

    # renpy/common/00action_file.rpy:983
    old "Quick load."
    new "Быстрая загрузка."

    # renpy/common/00action_other.rpy:416
    old "Language [text]"
    new "Язык [text]"

    # renpy/common/00action_other.rpy:786
    old "Open [text] directory."
    new "Открыть [text] папку."

    # renpy/common/00director.rpy:712
    old "The interactive director is not enabled here."
    new "Интерактивный режиссёр здесь не включён."

    # renpy/common/00director.rpy:1512
    old "⬆"
    new "Стрелка вверх"

    # renpy/common/00director.rpy:1518
    old "⬇"
    new "Стрелка вниз"

    # renpy/common/00director.rpy:1582
    old "Done"
    new "Готово"

    # renpy/common/00director.rpy:1592
    old "(statement)"
    new "(statement)"

    # renpy/common/00director.rpy:1593
    old "(tag)"
    new "(tag)"

    # renpy/common/00director.rpy:1594
    old "(attributes)"
    new "(attributes)"

    # renpy/common/00director.rpy:1595
    old "(transform)"
    new "(transform)"

    # renpy/common/00director.rpy:1620
    old "(transition)"
    new "(transition)"

    # renpy/common/00director.rpy:1632
    old "(channel)"
    new "(channel)"

    # renpy/common/00director.rpy:1633
    old "(filename)"
    new "(filename)"

    # renpy/common/00director.rpy:1662
    old "Change"
    new "Изменить"

    # renpy/common/00director.rpy:1664
    old "Add"
    new "Добавить"

    # renpy/common/00director.rpy:1667
    old "Cancel"
    new "Отменить"

    # renpy/common/00director.rpy:1670
    old "Remove"
    new "Удалить"

    # renpy/common/00director.rpy:1705
    old "Statement:"
    new "Оператор:"

    # renpy/common/00director.rpy:1726
    old "Tag:"
    new "Тег:"

    # renpy/common/00director.rpy:1742
    old "Attributes:"
    new "Атрибуты:"

    # renpy/common/00director.rpy:1753
    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Щёлкните, чтобы переключить атрибут, щёлкните правой кнопкой для переключения отрицательного атрибута."

    # renpy/common/00director.rpy:1765
    old "Transforms:"
    new "Преобразования:"

    # renpy/common/00director.rpy:1776
    old "Click to set transform, right click to add to transform list."
    new "Щёлкните, чтобы установить преобразование, щёлкните правой кнопкой, чтобы добавить в список преобразований."

    # renpy/common/00director.rpy:1777
    old "Customize director.transforms to add more transforms."
    new "Настройте director.transforms, чтобы добавить больше преобразований."

    # renpy/common/00director.rpy:1789
    old "Behind:"
    new "Позади:"

    # renpy/common/00director.rpy:1800
    old "Click to set, right click to add to behind list."
    new "Щёлкните, чтобы установить, щёлкните правой кнопкой, чтобы добавить в список позади."

    # renpy/common/00director.rpy:1812
    old "Transition:"
    new "Переход:"

    # renpy/common/00director.rpy:1822
    old "Click to set."
    new "Щёлкните, чтобы установить."

    # renpy/common/00director.rpy:1823
    old "Customize director.transitions to add more transitions."
    new "Настройте director.transitions, чтобы добавить больше переходов."

    # renpy/common/00director.rpy:1835
    old "Channel:"
    new "Канал:"

    # renpy/common/00director.rpy:1846
    old "Customize director.audio_channels to add more channels."
    new "Настройте director.audio_channels, чтобы добавить больше каналов."

    # renpy/common/00director.rpy:1858
    old "Audio Filename:"
    new "Имя аудиофайла:"

    # renpy/common/00gui.rpy:448
    old "Are you sure?"
    new "Вы уверены?"

    # renpy/common/00gui.rpy:449
    old "Are you sure you want to delete this save?"
    new "Вы уверены, что хотите удалить это сохранение?"

    # renpy/common/00gui.rpy:450
    old "Are you sure you want to overwrite your save?"
    new "Вы уверены, что хотите перезаписать сохранение?"

    # renpy/common/00gui.rpy:451
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Загрузка приведёт к потере несохранённого прогресса.\nВы уверены, что хотите это сделать?"

    # renpy/common/00gui.rpy:452
    old "Are you sure you want to quit?"
    new "Вы уверены, что хотите выйти?"

    # renpy/common/00gui.rpy:453
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Вы уверены, что хотите вернуться в главное меню?\nЭто приведёт к потере несохранённого прогресса."

    # renpy/common/00gui.rpy:454
    old "Are you sure you want to continue where you left off?"
    new "Вы уверены, что хотите продолжить с того места, где остановились?"

    # renpy/common/00gui.rpy:455
    old "Are you sure you want to end the replay?"
    new "Вы уверены, что хотите завершить повтор?"

    # renpy/common/00gui.rpy:456
    old "Are you sure you want to begin skipping?"
    new "Вы уверены, что хотите начать пропуск?"

    # renpy/common/00gui.rpy:457
    old "Are you sure you want to skip to the next choice?"
    new "Вы уверены, что хотите перейти к следующему выбору?"

    # renpy/common/00gui.rpy:458
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Вы уверены, что хотите пропустить непрочитанный диалог до следующего выбора?"

    # renpy/common/00gui.rpy:459
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Эта сохранённая игра была создана на другом устройстве. Злонамеренно созданные файлы сохранения могут нанести вред вашему компьютеру. Доверяете ли вы создателю сохранения и всем, кто мог изменить файл?"

    # renpy/common/00gui.rpy:460
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "Доверяете ли вы устройству, на котором было создано сохранение? Выбирайте \"да\" только если вы единственный пользователь этого устройства."

    # renpy/common/00keymap.rpy:325
    old "Failed to save screenshot as %s."
    new "Не удалось сохранить скриншот как %s."

    # renpy/common/00keymap.rpy:346
    old "Saved screenshot as %s."
    new "Скриншот сохранён как %s."

    # renpy/common/00library.rpy:257
    old "Skip Mode"
    new "Режим пропуска"

    # renpy/common/00library.rpy:344
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Эта программа содержит свободное программное обеспечение под несколькими лицензиями, включая лицензию MIT и GNU Lesser General Public License. Полный список программного обеспечения, включая ссылки на полный исходный код, можно найти {a=https://www.renpy.org/l/license}здесь{/a}."

    # renpy/common/00preferences.rpy:295
    old "display"
    new "отображение"

    # renpy/common/00preferences.rpy:315
    old "transitions"
    new "переходы"

    # renpy/common/00preferences.rpy:324
    old "skip transitions"
    new "пропускать переходы"

    # renpy/common/00preferences.rpy:326
    old "video sprites"
    new "видео-спрайты"

    # renpy/common/00preferences.rpy:335
    old "show empty window"
    new "показывать пустое окно"

    # renpy/common/00preferences.rpy:344
    old "text speed"
    new "скорость текста"

    # renpy/common/00preferences.rpy:352
    old "joystick"
    new "джойстик"

    # renpy/common/00preferences.rpy:352
    old "joystick..."
    new "джойстик..."

    # renpy/common/00preferences.rpy:359
    old "skip"
    new "пропуск"

    # renpy/common/00preferences.rpy:362
    old "skip unseen [text]"
    new "пропускать непрочитанный [text]"

    # renpy/common/00preferences.rpy:367
    old "skip unseen text"
    new "пропускать непрочитанный текст"

    # renpy/common/00preferences.rpy:369
    old "begin skipping"
    new "начать пропуск"

    # renpy/common/00preferences.rpy:373
    old "after choices"
    new "после выбора"

    # renpy/common/00preferences.rpy:380
    old "skip after choices"
    new "пропускать после выбора"

    # renpy/common/00preferences.rpy:382
    old "auto-forward time"
    new "автоматический пропуск времени"

    # renpy/common/00preferences.rpy:396
    old "auto-forward"
    new "автоматическое пролистывание"

    # renpy/common/00preferences.rpy:403
    old "Auto forward"
    new "Автоматическое пролистывание"

    # renpy/common/00preferences.rpy:406
    old "auto-forward after click"
    new "автоматическое пролистывание после клика"

    # renpy/common/00preferences.rpy:415
    old "automatic move"
    new "автоматическое перемещение"

    # renpy/common/00preferences.rpy:424
    old "wait for voice"
    new "ожидание голоса"

    # renpy/common/00preferences.rpy:433
    old "voice sustain"
    new "удержание голоса"

    # renpy/common/00preferences.rpy:442
    old "self voicing"
    new "собственное озвучивание"

    # renpy/common/00preferences.rpy:445
    old "self voicing enable"
    new "включить собственное озвучивание"

    # renpy/common/00preferences.rpy:447
    old "self voicing disable"
    new "отключить собственное озвучивание"

    # renpy/common/00preferences.rpy:451
    old "self voicing volume drop"
    new "снижение громкости при озвучивании"

    # renpy/common/00preferences.rpy:459
    old "clipboard voicing"
    new "озвучивание буфера обмена"

    # renpy/common/00preferences.rpy:462
    old "clipboard voicing enable"
    new "включить озвучивание буфера обмена"

    # renpy/common/00preferences.rpy:464
    old "clipboard voicing disable"
    new "отключить озвучивание буфера обмена"

    # renpy/common/00preferences.rpy:468
    old "debug voicing"
    new "отладка озвучивания"

    # renpy/common/00preferences.rpy:471
    old "debug voicing enable"
    new "включить отладку озвучивания"

    # renpy/common/00preferences.rpy:473
    old "debug voicing disable"
    new "отключить отладку озвучивания"

    # renpy/common/00preferences.rpy:477
    old "emphasize audio"
    new "усиление звука"

    # renpy/common/00preferences.rpy:486
    old "rollback side"
    new "откат стороны"

    # renpy/common/00preferences.rpy:496
    old "gl powersave"
    new "энергосбережение OpenGL"

    # renpy/common/00preferences.rpy:502
    old "gl framerate"
    new "частота кадров OpenGL"

    # renpy/common/00preferences.rpy:505
    old "gl tearing"
    new "разрыв кадров"

    # renpy/common/00preferences.rpy:508
    old "font transform"
    new "преобразование шрифта"

    # renpy/common/00preferences.rpy:511
    old "font size"
    new "размер шрифта"

    # renpy/common/00preferences.rpy:519
    old "font line spacing"
    new "межстрочное расстояние"

    # renpy/common/00preferences.rpy:527
    old "system cursor"
    new "системный курсор"

    # renpy/common/00preferences.rpy:536
    old "renderer menu"
    new "меню рендерера"

    # renpy/common/00preferences.rpy:539
    old "accessibility menu"
    new "меню специальных возможностей"

    # renpy/common/00preferences.rpy:542
    old "high contrast text"
    new "текст с высокой контрастностью"

    # renpy/common/00preferences.rpy:551
    old "audio when minimized"
    new "звук при свёртывании"

    # renpy/common/00preferences.rpy:560
    old "audio when unfocused"
    new "звук при неактивном окне"

    # renpy/common/00preferences.rpy:569
    old "web cache preload"
    new "предварительная загрузка веб-кэша"

    # renpy/common/00preferences.rpy:584
    old "voice after game menu"
    new "голос после игрового меню"

    # renpy/common/00preferences.rpy:593
    old "restore window position"
    new "восстановить позицию окна"

    # renpy/common/00preferences.rpy:602
    old "mono audio"
    new "монофонический звук"

    # renpy/common/00preferences.rpy:611
    old "font kerning"
    new "кернинг шрифта"

    # renpy/common/00preferences.rpy:619
    old "reset"
    new "сброс"

    # renpy/common/00preferences.rpy:632
    old "main volume"
    new "общая громкость"

    # renpy/common/00preferences.rpy:633
    old "music volume"
    new "громкость музыки"

    # renpy/common/00preferences.rpy:634
    old "sound volume"
    new "громкость звуков"

    # renpy/common/00preferences.rpy:635
    old "voice volume"
    new "громкость голоса"

    # renpy/common/00preferences.rpy:636
    old "mute main"
    new "отключить звук полностью"

    # renpy/common/00preferences.rpy:637
    old "mute music"
    new "отключить музыку"

    # renpy/common/00preferences.rpy:638
    old "mute sound"
    new "отключить звуки"

    # renpy/common/00preferences.rpy:639
    old "mute voice"
    new "отключить голос"

    # renpy/common/00preferences.rpy:640
    old "mute all"
    new "отключить всё"

    # renpy/common/00preferences.rpy:723
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Озвучивание буфера обмена включено. Нажмите 'shift+C' для отключения."

    # renpy/common/00preferences.rpy:725
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "Самоозвучивание произнесло бы \"[renpy.display.tts.last]\". Нажмите 'alt+shift+V' для отключения."

    # renpy/common/00preferences.rpy:727
    old "Self-voicing enabled. Press 'v' to disable."
    new "Самоозвучивание включено. Нажмите 'v' для отключения."

    # renpy/common/00speechbubble.rpy:420
    old "Speech Bubble Editor"
    new "Редактор речевых пузырей"

    # renpy/common/00speechbubble.rpy:425
    old "(hide)"
    new "(hide)"

    # renpy/common/00speechbubble.rpy:436
    old "(clear retained bubbles)"
    new "(clear retained bubbles)"

    # renpy/common/00sync.rpy:70
    old "Sync downloaded."
    new "Синхронизация загружена."

    # renpy/common/00sync.rpy:184
    old "Could not connect to the Ren'Py Sync server."
    new "Не удалось подключиться к серверу синхронизации Ren'Py."

    # renpy/common/00sync.rpy:186
    old "The Ren'Py Sync server timed out."
    new "Истекло время ожидания ответа от сервера синхронизации Ren'Py."

    # renpy/common/00sync.rpy:188
    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Произошла неизвестная ошибка при подключении к серверу синхронизации Ren'Py."

    # renpy/common/00sync.rpy:204
    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "На сервере синхронизации Ren'Py нет копии этой синхронизации. ID синхронизации может быть недействительным или истёк срок его действия."

    # renpy/common/00sync.rpy:305
    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Пожалуйста, введите сгенерированный вами ID синхронизации.\nНикогда не вводите ID синхронизации, который вы не создавали сами."

    # renpy/common/00sync.rpy:324
    old "The sync ID is not in the correct format."
    new "ID синхронизации указан в неверном формате."

    # renpy/common/00sync.rpy:344
    old "The sync could not be decrypted."
    new "Синхронизация не может быть расшифрована."

    # renpy/common/00sync.rpy:367
    old "The sync belongs to a different game."
    new "Эта синхронизация принадлежит другой игре."

    # renpy/common/00sync.rpy:372
    old "The sync contains a file with an invalid name."
    new "Синхронизация содержит файл с недопустимым именем."

    # renpy/common/00sync.rpy:425
    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "Это загрузит ваши сохранения на {a=https://sync.renpy.org}сервер синхронизации Ren'Py{/a}.\nХотите продолжить?"

    # renpy/common/00sync.rpy:457
    old "Enter Sync ID"
    new "Введите ID синхронизации"

    # renpy/common/00sync.rpy:468
    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "Это установит соединение с {a=https://sync.renpy.org}сервером синхронизации Ren'Py{/a}."

    # renpy/common/00sync.rpy:498
    old "Sync Success"
    new "Синхронизация успешна"

    # renpy/common/00sync.rpy:501
    old "The Sync ID is:"
    new "ID синхронизации:"

    # renpy/common/00sync.rpy:507
    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Вы можете использовать этот ID для загрузки вашего сохранения на другом устройстве.\nЭта синхронизация истечёт через час.\nСинхронизация Ren'Py поддерживается {a=https://www.renpy.org/sponsors.html}спонсорами Ren'Py{/a}."

    # renpy/common/00sync.rpy:511
    old "Continue"
    new "Продолжить"

    # renpy/common/00sync.rpy:536
    old "Sync Error"
    new "Ошибка синхронизации"

    # renpy/common/00translation.rpy:63
    old "Translation identifier: [identifier]"
    new "Идентификатор перевода: [identifier]"

    # renpy/common/00translation.rpy:84
    old " translates [tl.filename]:[tl.linenumber]"
    new " переводит [tl.filename]:[tl.linenumber]"

    # renpy/common/00translation.rpy:101
    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Скопировано в буфер обмена.{/color}"

    # renpy/common/00iap.rpy:231
    old "Contacting App Store\nPlease Wait..."
    new "Подключение к App Store\nПожалуйста, подождите..."

    # renpy/common/00updater.rpy:415
    old "No update methods found."
    new "Методы обновления не найдены."

    # renpy/common/00updater.rpy:462
    old "Could not download file list: "
    new "Не удалось загрузить список файлов: "

    # renpy/common/00updater.rpy:465
    old "File list digest does not match."
    new "Хеш-сумма списка файлов не совпадает."

    # renpy/common/00updater.rpy:675
    old "An error is being simulated."
    new "Имитируется ошибка."

    # renpy/common/00updater.rpy:863
    old "Either this project does not support updating, or the update status file was deleted."
    new "Либо этот проект не поддерживает обновление, либо файл состояния обновления был удалён."

    # renpy/common/00updater.rpy:877
    old "This account does not have permission to perform an update."
    new "У этой учётной записи нет прав на выполнение обновления."

    # renpy/common/00updater.rpy:880
    old "This account does not have permission to write the update log."
    new "У этой учётной записи нет прав на запись журнала обновлений."

    # renpy/common/00updater.rpy:966
    old "Could not verify update signature."
    new "Не удалось проверить подпись обновления."

    # renpy/common/00updater.rpy:1289
    old "The update file was not downloaded."
    new "Файл обновления не был загружен."

    # renpy/common/00updater.rpy:1307
    old "The update file does not have the correct digest - it may have been corrupted."
    new "Файл обновления имеет неправильную хеш-сумму — возможно, он повреждён."

    # renpy/common/00updater.rpy:1457
    old "While unpacking {}, unknown type {}."
    new "При распаковке {}, неизвестный тип {}."

    # renpy/common/00updater.rpy:1928
    old "Updater"
    new "Обновление"

    # renpy/common/00updater.rpy:1935
    old "An error has occurred:"
    new "Произошла ошибка:"

    # renpy/common/00updater.rpy:1937
    old "Checking for updates."
    new "Проверка наличия обновлений."

    # renpy/common/00updater.rpy:1939
    old "This program is up to date."
    new "Эта программа обновлена до последней версии."

    # renpy/common/00updater.rpy:1941
    old "[u.version] is available. Do you want to install it?"
    new "[u.version] доступно. Хотите установить?"

    # renpy/common/00updater.rpy:1943
    old "Preparing to download the updates."
    new "Подготовка к загрузке обновлений."

    # renpy/common/00updater.rpy:1945
    old "Downloading the updates."
    new "Загрузка обновлений."

    # renpy/common/00updater.rpy:1947
    old "Unpacking the updates."
    new "Распаковка обновлений."

    # renpy/common/00updater.rpy:1949
    old "Finishing up."
    new "Завершение."

    # renpy/common/00updater.rpy:1951
    old "The updates have been installed. The program will restart."
    new "Обновления установлены. Программа перезапустится."

    # renpy/common/00updater.rpy:1953
    old "The updates have been installed."
    new "Обновления установлены."

    # renpy/common/00updater.rpy:1955
    old "The updates were cancelled."
    new "Обновление было отменено."

    # renpy/common/00updater.rpy:1970
    old "Proceed"
    new "Продолжить"

    # renpy/common/00updater.rpy:1986
    old "Preparing to download the game data."
    new "Подготовка к загрузке данных игры."

    # renpy/common/00updater.rpy:1988
    old "Downloading the game data."
    new "Загрузка данных игры."

    # renpy/common/00updater.rpy:1990
    old "The game data has been downloaded."
    new "Данные игры загружены."

    # renpy/common/00updater.rpy:1992
    old "An error occurred when trying to download game data:"
    new "Произошла ошибка при попытке загрузить данные игры:"

    # renpy/common/00updater.rpy:1997
    old "This game cannot be run until the game data has been downloaded."
    new "Эту игру нельзя запустить, пока не будут загружены данные игры."

    # renpy/common/00updater.rpy:2004
    old "Retry"
    new "Повторить"

    # renpy/common/00gallery.rpy:676
    old "Image [index] of [count] locked."
    new "Изображение [index] из [count] заблокировано."

    # renpy/common/00gallery.rpy:696
    old "prev"
    new "предыдущее"

    # renpy/common/00gallery.rpy:697
    old "next"
    new "следующее"

    # renpy/common/00gallery.rpy:698
    old "slideshow"
    new "слайд-шоу"

    # renpy/common/00gallery.rpy:699
    old "return"
    new "вернуться"

    # renpy/common/00gltest.rpy:89
    old "Renderer"
    new "Рендерер"

    # renpy/common/00gltest.rpy:91
    old "Automatically Choose"
    new "Автоматически выбрать"

    # renpy/common/00gltest.rpy:96
    old "Force GL2 Renderer"
    new "Принудительно использовать рендерер GL2"

    # renpy/common/00gltest.rpy:101
    old "Force ANGLE2 Renderer"
    new "Принудительно использовать рендерер ANGLE2"

    # renpy/common/00gltest.rpy:106
    old "Force GLES2 Renderer"
    new "Принудительно использовать рендерер GLES2"

    # renpy/common/00gltest.rpy:112
    old "Enable (No Blocklist)"
    new "Включить (No Blocklist)"

    # renpy/common/00gltest.rpy:135
    old "Powersave"
    new "Режим энергосбережения"

    # renpy/common/00gltest.rpy:145
    old "Framerate"
    new "Частота кадров"

    # renpy/common/00gltest.rpy:147
    old "Screen"
    new "Экран"

    # renpy/common/00gltest.rpy:151
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:155
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:159
    old "Tearing"
    new "Разрыв экрана"

    # renpy/common/00gltest.rpy:171
    old "Changes will take effect the next time this program is run."
    new "Изменения вступят в силу при следующем запуске программы."

    # renpy/common/00gltest.rpy:178
    old "Quit"
    new "Выход"

    # renpy/common/00gltest.rpy:207
    old "Performance Warning"
    new "Предупреждение о производительности"

    # renpy/common/00gltest.rpy:212
    old "This computer is using software rendering."
    new "На этом компьютере используется программный рендеринг."

    # renpy/common/00gltest.rpy:214
    old "This game requires use of GL2 that can't be initialised."
    new "Для этой игры требуется использование GL2, которое не может быть инициализировано."

    # renpy/common/00gltest.rpy:216
    old "This computer has a problem displaying graphics: [problem]."
    new "На этом компьютере возникла проблема с отображением графики: [problem]."

    # renpy/common/00gltest.rpy:220
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Драйверы графики могут быть устаревшими или работать некорректно. Это может привести к медленному или некорректному отображению графики."

    # renpy/common/00gltest.rpy:224
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "Файл {a=edit:1:log.txt}log.txt{/a} может содержать информацию, которая поможет определить, что не так с вашим компьютером."

    # renpy/common/00gltest.rpy:229
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Более подробную информацию о том, как это исправить, можно найти в {a=[url]}документации{/a}."

    # renpy/common/00gltest.rpy:234
    old "Continue, Show this warning again"
    new "Продолжить, показывать это предупреждение снова"

    # renpy/common/00gltest.rpy:238
    old "Continue, Don't show warning again"
    new "Продолжить, не показывать это предупреждение снова"

    # renpy/common/00gltest.rpy:246
    old "Change render options"
    new "зменить параметры рендеринга"

    # renpy/common/00gamepad.rpy:33
    old "Select Gamepad to Calibrate"
    new "Выберите геймпад для калибровки"

    # renpy/common/00gamepad.rpy:36
    old "No Gamepads Available"
    new "Геймпады недоступны"

    # renpy/common/00gamepad.rpy:56
    old "Calibrating [name] ([i]/[total])"
    new "Калибровка [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:60
    old "Press or move the '[control!s]' [kind]."
    new "Нажмите или переместите '[control!s]' [kind]."

    # renpy/common/00gamepad.rpy:70
    old "Skip (A)"
    new "Пропустить (A)"

    # renpy/common/00gamepad.rpy:73
    old "Back (B)"
    new "Назад (B)"

    # renpy/common/_errorhandling.rpym:758
    old "Open"
    new "Открыть"

    # renpy/common/_errorhandling.rpym:760
    old "Opens the traceback.txt file in a text editor."
    new "Открывает файл traceback.txt в текстовом редакторе."

    # renpy/common/_errorhandling.rpym:762
    old "Copy BBCode"
    new "Скопировать BBCode"

    # renpy/common/_errorhandling.rpym:764
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Копирует файл traceback.txt в буфер обмена в формате BBCode для форумов, таких как https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:766
    old "Copy Markdown"
    new "Скопировать Markdown"

    # renpy/common/_errorhandling.rpym:768
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Копирует файл traceback.txt в буфер обмена в формате Markdown для Discord."

    # renpy/common/_errorhandling.rpym:800
    old "An exception has occurred."
    new "Произошло исключение."

    # renpy/common/_errorhandling.rpym:829
    old "Rollback"
    new "Откат"

    # renpy/common/_errorhandling.rpym:831
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Пытается откатить игру к предыдущему моменту времени, позволяя вам сохранить игру или выбрать другой вариант действия."

    # renpy/common/_errorhandling.rpym:834
    old "Ignore"
    new "Игнорировать"

    # renpy/common/_errorhandling.rpym:838
    old "Ignores the exception, allowing you to continue."
    new "Игнорирует ошибку, позволяя вам продолжить игру."

    # renpy/common/_errorhandling.rpym:840
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Игнорирует ошибку, позволяя вам продолжить игру. Часто это приводит к дополнительным ошибкам."

    # renpy/common/_errorhandling.rpym:844
    old "Reload"
    new "Перезагрузка"

    # renpy/common/_errorhandling.rpym:846
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Перезагружает игру с диска, сохраняя и восстанавливая состояние игры, если это возможно."

    # renpy/common/_errorhandling.rpym:849
    old "Console"
    new "Консоль"

    # renpy/common/_errorhandling.rpym:851
    old "Opens a console to allow debugging the problem."
    new "Открывает консоль для отладки проблемы."

    # renpy/common/_errorhandling.rpym:864
    old "Quits the game."
    new "Завершает игру."

    # renpy/common/_errorhandling.rpym:886
    old "Parsing the script failed."
    new "Ошибка при разборе скрипта."
